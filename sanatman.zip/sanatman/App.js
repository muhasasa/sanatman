import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();

// Ana Sayfa
function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Sanatman</Text>
      {["Kitap", "Tiyatro", "Müzik", "Film", "Dizi", "Dergi"].map((item, index) => (
        <TouchableOpacity
          key={index}
          style={styles.button}
          onPress={() => navigation.navigate(item)}
        >
          <Text style={styles.buttonText}>{item}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

// Alt Ekranlar
function SubScreen({ route }) {
  const { category, options } = route.params;
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Sanatman</Text>
      <Text style={styles.subHeader}>{category}</Text>
      {options.map((option, index) => (
        <TouchableOpacity key={index} style={styles.button}>
          <Text style={styles.buttonText}>{option}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen
          name="Kitap"
          component={SubScreen}
          initialParams={{ category: "Kitap", options: ["Okuduklarım", "Okumak İstediklerim"] }}
        />
        <Stack.Screen
          name="Tiyatro"
          component={SubScreen}
          initialParams={{ category: "Tiyatro", options: ["Gittiklerim", "Gitmek İstediklerim"] }}
        />
        <Stack.Screen
          name="Müzik"
          component={SubScreen}
          initialParams={{ category: "Müzik", options: ["Beğendiklerim"] }}
        />
        <Stack.Screen
          name="Film"
          component={SubScreen}
          initialParams={{ category: "Film", options: ["İzlediklerim", "İzlemek İstediklerim"] }}
        />
        <Stack.Screen
          name="Dizi"
          component={SubScreen}
          initialParams={{ category: "Dizi", options: ["İzlediklerim", "İzlemek İstediklerim"] }}
        />
        <Stack.Screen
          name="Dergi"
          component={SubScreen}
          initialParams={{ category: "Dergi", options: ["Takip Ettiklerim"] }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  header: {
    fontSize: 36,
    fontWeight: "bold",
    color: "#6200ee",
    marginBottom: 16,
    textAlign: "center",
    textTransform: "uppercase",
  },
  subHeader: {
    fontSize: 24,
    fontWeight: "600",
    color: "#333",
    marginBottom: 24,
    textAlign: "center",
  },
  button: {
    backgroundColor: "#6200ee",
    padding: 16,
    marginVertical: 8,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
  },
});
